clc 
clear all
close all

load rotations2
lbr = importrobot("C:\Users\marco\Desktop\Thesis\Kinematics_Matlab\inverse\model\LRM_ARM_simplified_fixed.urdf");
lbr.DataFormat = 'row';
gripper = 'end_effector';

q0 = homeConfiguration(lbr);
qWaypoints = repmat(q0, 2, 1);

gik = generalizedInverseKinematics('RigidBodyTree', lbr, ...
    'ConstraintInputs', {'position','joint','orientation'});
gik.SolverParameters.MaxIterations = 10000;
gik.SolverParameters.MaxTime = 60;

posConst = constraintPositionTarget(gripper);
posConst.PositionTolerance = 0;

limitJointChange = constraintJointBounds(lbr);

fixOrientation = constraintOrientationTarget(gripper); %orientation

counter = 1

x = linspace(0,0.15,5);
y = linspace(0,0.3,5);

%% ANGLE 45°  0.7854

posConst.TargetPosition = [-0.12 0 0.24];
fixOrientation.TargetOrientation = rotations(1,:);
[qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
fixOrientation.OrientationTolerance = deg2rad(60);

if getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001 % found a solution
    
    % 1 retrieval
    fixOrientation.OrientationTolerance = deg2rad(10);
    [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
    RESULT(counter,1) = 45;
    RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
    RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
    RESULT(counter,4) = 1;
    RESULT(counter,5) = -0.12;
    RESULT(counter,6) = 0;
    RESULT(counter,7) = 0.24;
    RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
    counter = counter + 1

    % 2 retrieval
    fixOrientation.OrientationTolerance = deg2rad(30);
    fixOrientation.TargetOrientation = rotations(15,:);
    [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
    RESULT(counter,1) = 45;
    RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
    RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
    RESULT(counter,4) = 2;
    RESULT(counter,5) = -0.12;
    RESULT(counter,6) = 0;
    RESULT(counter,7) = 0.24;
    RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
    counter = counter + 1

    for i = 1:length(x) 
        for j = length(y)

            posConst.TargetPosition = [x(i) y(i) 0];

            % 3 grabbing
            fixOrientation.OrientationTolerance = deg2rad(10);
            fixOrientation.TargetOrientation = rotations(1,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 3;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1;
        
            % 4 grabbing
            fixOrientation.OrientationTolerance = deg2rad(5);
            fixOrientation.TargetOrientation = rotations(13,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 4;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1
        
            % 5 grabbing
            fixOrientation.OrientationTolerance = deg2rad(5);
            fixOrientation.TargetOrientation = rotations(8,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 5;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1
        end
    end
end

RESULT(counter:counter+2,:) = zeros(1,8);
counter = counter + 3

%% ANGLE 60° 1.0472

lbr.Bodies{1, 1}.Joint.JointToParentTransform(1,1) = cos(1.0472);
lbr.Bodies{1, 1}.Joint.JointToParentTransform(1,3) = sin(1.0472);
lbr.Bodies{1, 1}.Joint.JointToParentTransform(3,1) = -sin(1.0472);
lbr.Bodies{1, 1}.Joint.JointToParentTransform(3,3) = cos(1.0472);

posConst.TargetPosition = [-0.12 0 0.24];

fixOrientation.TargetOrientation = rotations(1,:);
[qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
fixOrientation.OrientationTolerance = deg2rad(60);

if getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001 % found a solution
    
    % 1 retrieval
    fixOrientation.OrientationTolerance = deg2rad(10);
    [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
    RESULT(counter,1) = 45;
    RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
    RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
    RESULT(counter,4) = 1;
    RESULT(counter,5) = -0.12;
    RESULT(counter,6) = 0;
    RESULT(counter,7) = 0.24;
    RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
    counter = counter + 1

    % 2 retrieval
    fixOrientation.OrientationTolerance = deg2rad(30);
    fixOrientation.TargetOrientation = rotations(15,:);
    [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
    RESULT(counter,1) = 45;
    RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
    RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
    RESULT(counter,4) = 2;
    RESULT(counter,5) = -0.12;
    RESULT(counter,6) = 0;
    RESULT(counter,7) = 0.24;
    RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
    counter = counter + 1

    for i = 1:length(x) 
        for j = length(y)

            posConst.TargetPosition = [x(i) y(i) 0];

            % 3 grabbing
            fixOrientation.OrientationTolerance = deg2rad(10);
            fixOrientation.TargetOrientation = rotations(1,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 3;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1
        
            % 4 grabbing
            fixOrientation.OrientationTolerance = deg2rad(5);
            fixOrientation.TargetOrientation = rotations(13,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 4;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1
        
            % 5 grabbing
            fixOrientation.OrientationTolerance = deg2rad(5);
            fixOrientation.TargetOrientation = rotations(8,:);
            [qWaypoints(2,:),solutionInfo] = gik(q0,posConst, limitJointChange,fixOrientation);
            RESULT(counter,1) = 45;
            RESULT(counter,2) = lbr.Bodies{1, 3}.Joint.JointToParentTransform(2,4);
            RESULT(counter,3) = lbr.Bodies{1, 5}.Joint.JointToParentTransform(2,4);
            RESULT(counter,4) = 5;
            RESULT(counter,5) = x(i);
            RESULT(counter,6) = y(i);
            RESULT(counter,7) = 0;
            RESULT(counter,8) = getfield(solutionInfo.ConstraintViolations,'Violation',{1}) < 0.0001;
            counter = counter + 1
        end
    end
end